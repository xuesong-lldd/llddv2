#!/bin/bash
#
# OP-TEE QEMU 交互式启动（前台，串口直接走 SSH stdio）
#
#   NW Linux       → 当前终端（直接交互，vim/Tab/历史都可用）
#   SW OP-TEE OS   → 日志文件（另一个 SSH 用 tail -f 看）
#
# 退出 QEMU Linux 'poweroff' 命令
#
# 用法：
#   ./optee-run-interactive.sh                # 用默认 SW log 路径
#   ./optee-run-interactive.sh /tmp/sw.log    # 自定义 SW log 路径
#
set -e

ROOT=/home/xuesong/linux/trainings/nj-siemens/optee-qemu
OUT_BIN=$ROOT/out/bin
QEMU=$ROOT/qemu/build/qemu-system-aarch64
SW_LOG=${1:-$ROOT/build/serial-sw.log}

# Sanity checks
[ -x "$QEMU" ]      || { echo "ERROR: QEMU binary not found: $QEMU"; exit 1; }
[ -f "$OUT_BIN/bl1.bin" ] || { echo "ERROR: bl1.bin not found in $OUT_BIN"; exit 1; }

# Make sure build/ exists for the SW log
mkdir -p "$(dirname "$SW_LOG")"

# Truncate previous SW log so tail -f starts fresh
: > "$SW_LOG"

cat <<EOF
[run] NW serial  → this terminal (interactive)
[run] SW serial  → $SW_LOG
[run]
[run] Watch SW in another SSH:
[run]     tail -f $SW_LOG
[run]
[run] Quit QEMU: Ctrl+A then X
[run]

EOF

# cd to OUT_BIN so the relative paths below (-bios bl1.bin, -initrd
# rootfs.cpio.gz, -kernel Image) resolve. Without this, QEMU inherits
# the caller's cwd (often build/) and fails with "Could not find ROM image".
cd "$OUT_BIN"

# exec so QEMU replaces this shell — signals go straight to QEMU
exec "$QEMU" \
    -nographic -smp 2 \
    -cpu max,sme=on,pauth-impdef=on \
    -d unimp \
    -semihosting-config enable=on,target=native \
    -m 1057 \
    -bios bl1.bin \
    -initrd rootfs.cpio.gz \
    -kernel Image \
    -append "console=ttyAMA0,38400 keep_bootcon root=/dev/vda2" \
    -machine virt,acpi=off,secure=on,mte=off,gic-version=3,virtualization=false \
    -object rng-random,filename=/dev/urandom,id=rng0 \
    -device virtio-rng-pci,rng=rng0,max-bytes=1024,period=1000 \
    -netdev user,id=vmnic \
    -device virtio-net-device,netdev=vmnic \
    -serial mon:stdio \
    -serial "file:$SW_LOG"
