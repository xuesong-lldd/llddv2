#!/usr/bin/env bash
# ===========================================================================
# Host wrapper: build + run the OP-TEE demo container interactively.
# ===========================================================================
# Usage:
#   ./run.sh              # interactive bash inside the container
#   ./run.sh /opt/phase1.sh   # run a specific command, then exit
#
# Workspace data lives in a Docker named volume (optee-qemu-workspace),
# so it survives container restarts and never touches your local FS.
# ===========================================================================
set -euo pipefail

# --- 0. Sanity check: docker must be installed ---------------------------
if ! command -v docker >/dev/null 2>&1; then
    echo "ERROR: 'docker' not found in PATH." >&2
    echo "       Please install Docker Engine first:" >&2
    echo "         https://docs.docker.com/engine/install/" >&2
    echo "       After install, make sure your user is in the 'docker' group:" >&2
    echo "         sudo usermod -aG docker \$USER && newgrp docker" >&2
    exit 1
fi
if ! docker info >/dev/null 2>&1; then
    echo "ERROR: 'docker info' failed — daemon not running or no permission." >&2
    echo "       Start docker.service / add your user to the 'docker' group." >&2
    exit 1
fi

IMAGE_TAG="optee-demo:latest"
WORKSPACE_VOLUME="optee-qemu-workspace"
WORKSPACE_DIR="/home/xuesong/linux/trainings/nj-siemens/optee-qemu"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# --- 1. Build image (cached after first time; takes ~1-2 minutes) -------
if ! docker image inspect "$IMAGE_TAG" >/dev/null 2>&1; then
    echo "[run] building image $IMAGE_TAG (first run only, ~1-2 min)..."
fi
docker build -q -t "$IMAGE_TAG" "$SCRIPT_DIR" >/dev/null

# --- 2. Create persistent volume if missing -----------------------------
if ! docker volume inspect "$WORKSPACE_VOLUME" >/dev/null 2>&1; then
    echo "[run] creating named volume $WORKSPACE_VOLUME"
    docker volume create "$WORKSPACE_VOLUME" >/dev/null
fi

# --- 3. Print quick-start banner ----------------------------------------
cat <<EOF

[run] ===================================================================
[run]  OP-TEE QEMU demo container
[run] ===================================================================
[run]  image        : $IMAGE_TAG
[run]  workspace    : named volume '$WORKSPACE_VOLUME'
[run]                mounted at $WORKSPACE_DIR
[run]  user         : xuesong (uid 1000, passwordless sudo)
[run] -------------------------------------------------------------------
[run]  Inside the container, try:
[run]    bash /opt/phase0.sh        # re-show Phase 0 (already baked in)
[run]    bash /opt/phase1.sh        # repo init + sync (~10-20 min)
[run]    ls \$PWD                    # your workspace
[run]    exit                        # leave; data persists in the volume
[run] ===================================================================

EOF

# --- 4. Run interactive container ---------------------------------------
# Notes:
#   --rm              container is discarded on exit (data is in the volume)
#   --hostname        friendly hostname in the prompt
#   -v <vol>:<dir>    mount the persistent workspace
#   "\$@" is intentionally passed through so callers can do:
#       ./run.sh /opt/phase1.sh
#   to run a single command non-interactively.
exec docker run --rm -it \
    --hostname optee-demo \
    -v "$WORKSPACE_VOLUME:$WORKSPACE_DIR" \
    --name "optee-demo-$$_$(date +%s)" \
    "$IMAGE_TAG" \
    "$@"
