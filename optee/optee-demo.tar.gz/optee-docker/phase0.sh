#!/usr/bin/env bash
# ===========================================================================
# Phase 0: install OP-TEE QEMU build dependencies (apt packages)
# ===========================================================================
# This is exactly the Phase 0 block from optee-demo-step-by-step.html.
#
# The Dockerfile has ALREADY executed Phase 0 at image build time, so
# running this script inside the container is a no-op that just shows
# what got installed. For classroom demo, it makes the steps explicit
# and reproducible. If you ever need to add a package on the fly, just
# append it to the list below and re-run.
#
# Usage:   bash /opt/phase0.sh
# ===========================================================================
set -euo pipefail

PACKAGES=(
    xterm
    uuid-dev
    ccache
    android-tools-adb
    android-tools-fastboot
    python3-pyelftools
    python3-cryptography
    openssl
    libssl-dev
    bc
    bison
    flex
    python3
    python3-pip
    git
    repo
    # build prerequisites needed for Phase 2/3 (NOT in the handbook's Phase 0
    # list because it assumes a dev machine already has them; on a minimal
    # Docker image they must be installed explicitly)
    build-essential
    make
    device-tree-compiler
    ninja-build
    libglib2.0-dev
    libpixman-1-dev
    libfdt-dev
    libslirp-dev
    libffi-dev
    libgnutls28-dev
    pkg-config
    python3-venv
    python3-setuptools
    python3-tomli
    python3-distro
    python3-jinja2
    cpio
    mtools
    gawk
    zip
    unzip
    dosfstools
)

echo "============================================================"
echo " Phase 0: install OP-TEE QEMU build dependencies"
echo "============================================================"
echo "Packages: ${PACKAGES[*]}"
echo

sudo apt-get update
sudo apt-get install -y "${PACKAGES[@]}"

echo
echo "============================================================"
echo " Phase 0 verification"
echo "============================================================"
echo "[verify] git:      $(git --version)"
echo "[verify] repo:     $(dpkg -l repo 2>/dev/null | awk '/^ii/ {print $3}')"
echo "[verify] python3:  $(python3 --version)"
echo "[verify] make:     $(make --version | head -1)"
echo "[verify] gcc:      $(gcc --version | head -1)"
echo "[verify] dtc:      $(dtc --version 2>&1 | head -1)"
echo "[verify] ninja:    $(ninja --version 2>&1 | head -1)"
echo
echo "[verify] key package versions:"
dpkg -l | awk '/^ii/ {print $2, $3}' \
    | grep -E '^(xterm|ccache|uuid-dev|libssl-dev|bison|flex|build-essential|make|device-tree-compiler|ninja-build|libglib2.0-dev|libpixman-1-dev|libfdt-dev|python3-pyelftools|python3-cryptography|android-tools-adb|android-tools-fastboot|repo) ' \
    | awk '{printf "  %-30s %s\n", $1, $2}'
echo
echo "[ok] Phase 0 complete. Next: bash /opt/phase1.sh"
