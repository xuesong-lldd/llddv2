# OP-TEE QEMU 演示环境（Docker 版）

本目录的分发物（4 个文件）：

+---------------+-------------------------------------------------------+
| 文件          | 作用                                                  |
+---------------|-------------------------------------------------------|
| `Dockerfile`  | 构建镜像（Phase 0：apt 依赖已预装）                   |
| `run.sh`      | host 端入口：构建镜像 + 进入交互式容器                |
| `phase0.sh`   | 容器内：列出已装依赖（Dockfile已预装）                |
| `phase1.sh`   | 容器内：`repo init` + `repo sync` 拉取 OP-TEE 源码    |
+---------------|-------------------------------------------------------+

另外还需要一个 host 端的启动脚本（演示 QEMU 时用）：

- `optee-run-interactive.sh` — 启动 QEMU，NW Linux 走当前终端，SW OP-TEE 走日志文件

## 1. 前置条件

1. **Docker 已安装**并能正常 `docker info`（不行就把当前用户加进 `docker` 组：`sudo usermod -aG docker $USER && newgrp docker`）。
2. **网络可达 GitHub / Gerrit**（`repo sync` 要下 2-3 GB）。如果在内网代理后面，先在 host 上配好 Docker 代理或 build args。
3. 磁盘空间 **≥ 30 GB**（容器内会编译 Linux/TF-A/optee_os/buildroot, 视构建机器性能，大约30分钟左右）。
4. 内存 **≥ 4 GB**（QEMU 演示阶段）。

## 2. 快速开始

```bash
# 把 5 个文件放一起（任何目录都行，路径无关）
ls
# Dockerfile  phase0.sh  phase1.sh  run.sh  optee-run-interactive.sh

# 一条命令进容器（首次会构建镜像，约 1-2 分钟）
./run.sh
```

进容器后提示符变成 `optee-demo:...$`，cwd 自动是 `/home/xuesong/linux/trainings/nj-siemens/optee-qemu`（容器内路径，对应 host 上 docker named volume `optee-qemu-workspace`）。

## 3. 容器内编译 OP-TEE（三步，约 30-60 分钟）

```bash
# Phase 1：拉源码（10-20 分钟，2-3 GB）
bash /opt/phase1.sh

# Phase 2：拉 toolchain
cd build && make toolchains -j$(nproc)

# Phase 3：编译所有组件（bl1/bl2/bl31/optee_os/u-boot/linux/rootfs/qemu）
make -j$(nproc)
```

编译产物在 `out/bin/` 下（`bl1.bin`、`Image`、`rootfs.cpio.gz` 等软链）。

## 4. 启动 QEMU 做演示

`run.sh` 启动的容器名是动态的（`optee-demo-<pid>_<ts>`），每次都不一样。下面给出"开箱即用"的命令。

### 4.1 把 `optee-run-interactive.sh` 拷进容器（另开一个 host 终端）

**自动找容器名**（推荐）：

```bash
docker cp optee-run-interactive.sh \
    "$(docker ps --filter ancestor=optee-demo:latest --format '{{.Names}}' | head -1)":/home/xuesong/
```

**手动两步**：

```bash
docker ps                                    # 找到 NAMES 列，比如 optee-demo-12345_1721543abc
docker cp optee-run-interactive.sh optee-demo-12345_1721543abc:/home/xuesong/
```

> 一次拷贝即可。只要数据还在 `optee-qemu-workspace` volume 里、并且 `optee-run-interactive.sh` 拷到容器内 home（home 目录在 image 里，不在 volume 里 — 容器退出 `--rm` 后会丢），下次重进容器要重新拷一份。
>
> 如果想"一劳永逸"，直接把它拷到 volume 根目录里：
> ```bash
> sudo cp optee-run-interactive.sh \
>     /var/lib/docker/volumes/optee-qemu-workspace/_data/
> ```
> 这样每次进容器，`/home/xuesong/linux/trainings/nj-siemens/optee-qemu/optee-run-interactive.sh` 就自动在。

### 4.2 容器内启动 QEMU（回到第一个终端，仍在容器里）

```bash
cd /home/xuesong/linux/trainings/nj-siemens/optee-qemu
bash /home/xuesong/optee-run-interactive.sh
```

- **NW Linux** 直接显示在当前终端，可正常交互、登录。
- **SW OP-TEE** 日志写入容器内 `/home/xuesong/linux/trainings/nj-siemens/optee-qemu/build/serial-sw.log`。
- 退出 QEMU：`Ctrl+A 松开再按 X`。

### 4.3 另开 host 终端看 SW 日志（`tail -f`）

**方法 A（推荐，无需 sudo）**：再 `docker exec` 进同一个容器：

```bash
CONTAINER="$(docker ps --filter ancestor=optee-demo:latest --format '{{.Names}}' | head -1)"
docker exec -it "$CONTAINER" \
    tail -f /home/xuesong/linux/trainings/nj-siemens/optee-qemu/build/serial-sw.log
```

**方法 B（host 上直接看 volume 文件）**：

```bash
sudo tail -f /var/lib/docker/volumes/optee-qemu-workspace/_data/build/serial-sw.log
```

> 需要 sudo 是因为 `/var/lib/docker/` 属于 root。文件确实在那个路径下，因为容器里的 `.../optee-qemu/` 就是这个 volume 的挂载点。

## 5. 退出与再进

- 容器里 `exit` 或 host 端 `Ctrl+D` → 容器被 `--rm` 删除，但 volume `optee-qemu-workspace` 里的源码/编译产物**保留**。
- 下次 `./run.sh` 重新进容器：源码和 `out/bin/` 都还在，不用再 phase1。
- 想清空重来：`docker volume rm optee-qemu-workspace`，下次进容器会是空的 workspace。

## 6. 修改 TA 后重新演示

```bash
# 容器内
cd /home/xuesong/linux/trainings/nj-siemens/optee-qemu
vim optee_examples/hello_world/ta/*.c
cd build
make -j$(nproc)                    # 自动重编 TA 并打包进 rootfs.cpio.gz
# 退出 QEMU，重跑 4.2 即可看到新 TA
```

签名 key 在 `optee_os/keys/default_ta.pem`。

## 7. 常见问题

+-----------------------------------------------+-------------------------------------------------------------------------------------------------------------------------+
| 现象                                          | 原因 / 解决                                                                                                             |
| ----------------------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| `./run.sh` 报 `docker: command not found`     | 没装 Docker（脚本已加 sanity check，会打印安装链接）                                                                    |
| `docker info` 失败、permission denied         | 当前用户不在 `docker` 组：`sudo usermod -aG docker $USER && newgrp docker`                                              |
| `phase1.sh` 卡死 / 403                        | 网络代理问题。在 host 上配好 Docker daemon 代理，或进容器后 `export HTTPS_PROXY=...` 再跑                               |
| QEMU 起不来报 `Could not find ROM image`      | 没在 `out/bin/` 目录里跑。脚本会自己 cd 过去，但如果你改过脚本要确认                                                    |
| `tail -f` 文件不存在                          | QEMU 还没启动，或 SW log 路径不对。先进容器 `ls /home/xuesong/linux/trainings/nj-siemens/optee-qemu/build/serial-sw.log`|
| 容器退出后 optee-run-interactive.sh 没了      | home 目录在 image 里，不在 volume 里。下次重进容器要重新拷；或按 4.1 的"一劳永逸"做法放进 volume                        |
+-----------------------------------------------+-------------------------------------------------------------------------------------------------------------------------+

## 8. 演示所需文件清单

需要用到的文件：

```
optee-docker/                # 这个目录
├── Dockerfile
├── phase0.sh
├── phase1.sh
├── run.sh
└── README.md                # 本文件

optee-run-interactive.sh     # 跟 optee-docker/ 平级放一份即可
```

打包建议：

```bash
tar czf optee-demo.tar.gz optee-docker/ optee-run-interactive.sh
```
