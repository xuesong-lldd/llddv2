#!/usr/bin/env bash
# ===========================================================================
# Phase 1: initialise OP-TEE workspace + repo sync
# ===========================================================================
# Mirrors Phase 1 of optee-demo-step-by-step.html (pinned to OP-TEE 4.10.0).
#
# Environment overrides (optional):
#   WORKSPACE  path to workspace dir (default: /home/xuesong/linux/trainings/nj-siemens/optee-qemu)
#   OPTEE_TAG  OP-TEE release tag      (default: 4.10.0)
#   JOBS       parallelism for repo    (default: $(nproc))
#
# Usage:   bash /opt/phase1.sh
# ===========================================================================
set -euo pipefail

WORKSPACE="${WORKSPACE:-/home/xuesong/linux/trainings/nj-siemens/optee-qemu}"
OPTEE_TAG="${OPTEE_TAG:-4.10.0}"
JOBS="${JOBS:-$(nproc)}"

echo "============================================================"
echo " Phase 1: repo init + repo sync"
echo "============================================================"
echo "[phase1] workspace : $WORKSPACE"
echo "[phase1] OP-TEE tag: $OPTEE_TAG"
echo "[phase1] parallel  : -j$JOBS"
echo
echo "[phase1] network setup (corporate proxy):"
echo "[phase1]   HTTPS_PROXY = ${HTTPS_PROXY:-(not set)}"
echo "[phase1]   NO_PROXY    = ${NO_PROXY:-(not set)}"
if [ -f "$HOME/.gitconfig" ]; then
    echo "[phase1]   git http.proxy = $(git config --global http.proxy || echo 'n/a')"
fi
echo

mkdir -p "$WORKSPACE"
cd "$WORKSPACE"

# 1. repo init  (skip if already initialised — supports re-runs)
if [ -d ".repo" ]; then
    echo "[phase1] .repo/ already exists — skipping 'repo init'"
    echo "[phase1]   (to re-init from scratch: rm -rf $WORKSPACE/.repo)"
else
    echo "[phase1] running repo init..."
    repo init -u https://github.com/OP-TEE/manifest.git \
              -m qemu_v8.xml \
              -b "refs/tags/$OPTEE_TAG"
fi

echo

# 2. repo sync  (full sync, ~2-3GB, 10-20 minutes on first run)
echo "[phase1] running repo sync..."
echo "[phase1]   first sync downloads ~22 repos / 2-3 GB — be patient"
echo "[phase1]   follow progress in /tmp/repo-sync.log"
echo

time repo sync -j"$JOBS" -c --no-clone-bundle 2>&1 | tee /tmp/repo-sync.log

echo
echo "============================================================"
echo " Phase 1 verification"
echo "============================================================"
echo "[verify] workspace contents:"
ls -la "$WORKSPACE" | head -40
echo

EXPECTED_DIRS=(build qemu linux optee_os trusted-firmware-a optee_client optee_examples buildroot)
echo "[verify] checking expected subdirectories:"
for d in "${EXPECTED_DIRS[@]}"; do
    if [ -d "$WORKSPACE/$d" ]; then
        echo "   [ok]   $d/"
    else
        echo "   [MISSING] $d/"
    fi
done
echo
echo "[ok] Phase 1 complete."
echo "     Next steps (outside this script):"
echo "       cd $WORKSPACE/build"
echo "       make -j\$(nproc) toolchains   # Phase 2"
echo "       make -j\$(nproc)              # Phase 3"
